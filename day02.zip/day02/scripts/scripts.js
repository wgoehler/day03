//let xHTTP = new XMLHttpRequest();
let url = "http://localhost:8000/getweights";
function getRecords(){
	fetch(url)
	.then(function(response){
		return (response.json());
	}).then(function(data){
		console.log(data);
		displayData(data);
	});

}
//
function displayData(dataArray){
	let htmlOut = "";
	for(let i=0; i<dataArray.length; i++){
		htmlOut+=dataArray[i].empName + " weighed " + dataArray[i].empWeight + " Kgs<br />";
	}
	document.getElementById("records").innerHTML=htmlOut;
}
//
let pTags = document.getElementsByTagName('p'); 
for(let i = 0; i < pTags.length; i++) { 
	pTags[i].addEventListener('mouseover', function(){ 
		this.style.backgroundColor='lightyellow';}, false); 
	//
	pTags[i].addEventListener('mouseout', function(){ 
		this.style.backgroundColor='transparent';}, false); 
}			
//
let inputTags = document.getElementsByTagName('input'); 
for(let i = 0; i < inputTags.length; i++) { 
	inputTags[i].addEventListener('mouseover', function(){ 
		this.style.backgroundColor='lightyellow';}, false); 
	//
	inputTags[i].addEventListener('mouseout', function(){ 
		this.style.backgroundColor='transparent';}, false); 
}
//
function validateForm(){
	 let empName = document.forms["frmCollectWeights"]["empName"]; 
     let empWeight = document.forms["frmCollectWeights"]["empWeight"]; 
     if (empName.value == "") {  
            document.getElementById("emptyName").innerHTML="Name cannot be empty!"; 
            empName.focus();  
			return false;  
     }  	 
	return true;
}